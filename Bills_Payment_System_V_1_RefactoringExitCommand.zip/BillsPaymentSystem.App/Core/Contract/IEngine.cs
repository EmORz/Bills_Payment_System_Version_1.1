﻿namespace BillsPaymentSystem.App.Core.Contract
{
    public interface IEngine
    {
        void Run();
    }
}