﻿namespace BillsPaymentSystem.Models.Enum
{
    public enum PaymentType
    {
        BankAccount =0,
        CreditCard = 1
    }
}